import React from 'react'

function Header() {
  return (
    <div className='Header'>Header</div>
  )
}

export default Header