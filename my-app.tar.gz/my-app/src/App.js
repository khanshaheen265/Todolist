import './App.css';
import Todo from './component/todo';


function App() {
  return (
    <div>
      <Todo/>
    </div>
  );
}

export default App;
